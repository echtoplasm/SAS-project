// local
// define("DB_SERVER", "localhost");
// define("DB_USER", "sally");
// define("DB_PASS", "somepa55word");
// define("DB_NAME", "salamanders");

//a2
define("DB_SERVER", "localhost");
define("DB_USER", "charli12_doall");
define("DB_PASS", "ErYje7HV2o2Lqp7B9gx");
define("DB_NAME", "charli12_salamanders");